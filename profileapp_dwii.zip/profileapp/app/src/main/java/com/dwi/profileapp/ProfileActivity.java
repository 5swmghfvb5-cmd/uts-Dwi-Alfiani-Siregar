package com.dwi.profileapp;

import android.content.SharedPreferences;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

public class ProfileActivity extends AppCompatActivity {

    private boolean isFollowing = false;

    private final String[] followerNames = {
            "Kristin Watson", "Cody Fisher", "Jacob Jones", "Marvin McKinney", "Savannah Nguyen"
    };

    private final int[] followerPhotos = {
            R.drawable.follower1, R.drawable.follower2, R.drawable.follower3,
            R.drawable.follower4, R.drawable.follower5
    };

    private final int[] postPhotos = {
            R.drawable.post1, R.drawable.post2, R.drawable.post3,
            R.drawable.post4, R.drawable.post5, R.drawable.post6
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);

        TextView tvEditProfile = findViewById(R.id.tvEditProfile);
        Button btnFollow = findViewById(R.id.btnFollow);
        LinearLayout containerFollowers = findViewById(R.id.containerFollowers);
        RecyclerView rvPosts = findViewById(R.id.rvPosts);

        tvEditProfile.setOnClickListener(v ->
                startActivity(new Intent(this, EditProfileActivity.class)));

        btnFollow.setOnClickListener(v -> {
            isFollowing = !isFollowing;
            btnFollow.setText(isFollowing ? "Following" : "Follow");
        });

        // Daftar followers (horizontal)
        LayoutInflater inflater = LayoutInflater.from(this);
        for (int i = 0; i < followerNames.length; i++) {
            View item = inflater.inflate(R.layout.item_follower, containerFollowers, false);
            ((TextView) item.findViewById(R.id.tvFollowerName)).setText(followerNames[i]);
            ((ImageView) item.findViewById(R.id.imgFollower)).setImageResource(followerPhotos[i]);
            containerFollowers.addView(item);
        }

        // Grid posts 3 kolom
        rvPosts.setLayoutManager(new GridLayoutManager(this, 3));
        rvPosts.setAdapter(new PostAdapter(postPhotos));
    }

    @Override
    protected void onResume() {
        super.onResume();
        SharedPreferences prefs = getSharedPreferences("profile", MODE_PRIVATE);

        TextView tvName = findViewById(R.id.tvName);
        TextView tvBio = findViewById(R.id.tvBio);

        tvName.setText(prefs.getString("name", "Devon Lane"));
        tvBio.setText(prefs.getString("bio",
                "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore."));
    }

    // Adapter untuk grid post
    private static class PostAdapter extends RecyclerView.Adapter<PostAdapter.VH> {
        private final int[] photos;

        PostAdapter(int[] photos) {
            this.photos = photos;
        }

        @NonNull
        @Override
        public VH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View v = LayoutInflater.from(parent.getContext())
                    .inflate(R.layout.item_post, parent, false);
            return new VH(v);
        }

        @Override
        public void onBindViewHolder(@NonNull VH holder, int position) {
            holder.img.setImageResource(photos[position]);
        }

        @Override
        public int getItemCount() {
            return photos.length;
        }

        static class VH extends RecyclerView.ViewHolder {
            ImageView img;

            VH(@NonNull View itemView) {
                super(itemView);
                img = (ImageView) itemView;
            }
        }
    }
}